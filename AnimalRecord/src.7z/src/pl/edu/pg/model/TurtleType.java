package pl.edu.pg.model;
public enum TurtleType {
    LADOWY, BLOTNY, MORSKI;


}
