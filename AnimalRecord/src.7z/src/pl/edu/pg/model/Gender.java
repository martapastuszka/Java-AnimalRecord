package pl.edu.pg.model;

public enum Gender {
    FEMALE, MALE, NEUTRAL
}
